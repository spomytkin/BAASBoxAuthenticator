package com.baasbox.android.auth;


import android.app.Service;
import android.content.Intent;
import android.os.IBinder;


public class BBAuthenticatorService extends Service {
    @Override
    public IBinder onBind(Intent intent) {

        BBAuthenticator authenticator = new BBAuthenticator(this);
        return authenticator.getIBinder();
    }
}
