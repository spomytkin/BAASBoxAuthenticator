package com.baasbox.android.auth;



/**
 * Handles the comminication with BBox 
 *
 */
public class BBServerAuthenticate implements ServerAuthenticate{
    @Override
    public String userSignUp(String name, String email, String pass, String authType) throws Exception {


        //TODO create user, return token
     
        String authtoken = "123";


        return authtoken;
    }

    @Override
    public String userSignIn(String user, String pass, String authType) throws Exception {

    //TODO try to use token, get new if needed


        String authtoken="234";
		return authtoken;
    }


}
