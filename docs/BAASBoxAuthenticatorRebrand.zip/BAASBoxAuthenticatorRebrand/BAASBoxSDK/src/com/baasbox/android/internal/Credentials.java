package com.baasbox.android.internal;

public final class Credentials {

	public String sessionToken;
	public String username;
	public String password;
	
}
